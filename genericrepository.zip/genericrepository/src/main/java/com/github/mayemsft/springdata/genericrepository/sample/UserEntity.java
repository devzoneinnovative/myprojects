package com.github.mayemsft.springdata.genericrepository.sample;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Project: demo
 * Package: com.github.mayemsft.springdata.genericrepository.sample
 * <p>
 * User: ashisas
 * Date: 26-02-2022
 * Time: 16:18
 * <p>
 * Created with IntelliJ IDEA
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "user_details")
public class UserEntity extends BaseModel{

    private String name;
    private String address;
    private String email;
    private String phoneNUmber;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNUmber() {
        return phoneNUmber;
    }

    public void setPhoneNUmber(String phoneNUmber) {
        this.phoneNUmber = phoneNUmber;
    }
}
