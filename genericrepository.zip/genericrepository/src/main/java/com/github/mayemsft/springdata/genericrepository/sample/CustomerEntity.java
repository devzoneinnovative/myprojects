package com.github.mayemsft.springdata.genericrepository.sample;

import javax.persistence.Entity;

/**
 * Project: demo
 * Package: com.github.mayemsft.springdata.genericrepository.sample
 * <p>
 * User: ashisas
 * Date: 26-02-2022
 * Time: 21:09
 * <p>
 * Created with IntelliJ IDEA
 * To change this template use File | Settings | File Templates.
 */
@Entity
public class CustomerEntity extends BaseModel{

    private String customerName;
    private String customerId;
    private String customerAddress;
    private String customerEmail;

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }
}
