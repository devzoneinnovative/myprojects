package com.github.mayemsft.springdata.genericrepository;

import com.github.mayemsft.springdata.genericrepository.sample.BaseModel;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import javax.persistence.Entity;
import java.util.List;

public class CrudRepositoryHelper<T, ID> extends AbstractRepositoryHelper<T, ID> {

	@SuppressWarnings("unchecked")
	public CrudRepositoryHelper(Class<T> cls, Class<ID> id,
								ApplicationContext context) throws Exception {
		super(cls, id, JpaRepository.class, context);
		// TODO Auto-generated constructor stub
	}

	public CrudRepositoryHelper(List<Object> cls, Class<ID> id,
								ApplicationContext context) throws Exception {
		super(cls, id, JpaRepository.class, context);
		// TODO Auto-generated constructor stub
	}

}
