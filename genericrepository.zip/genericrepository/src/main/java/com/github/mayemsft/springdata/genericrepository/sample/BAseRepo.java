package com.github.mayemsft.springdata.genericrepository.sample;

import com.sun.xml.internal.bind.v2.model.core.ID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.io.Serializable;

/**
 * Project: demo
 * Package: com.github.mayemsft.springdata.genericrepository.sample
 * <p>
 * User: ashisas
 * Date: 26-02-2022
 * Time: 15:56
 * <p>
 * Created with IntelliJ IDEA
 * To change this template use File | Settings | File Templates.
 */
@Repository
public interface BAseRepo  extends JpaRepository<BaseModel, ID> {
}
