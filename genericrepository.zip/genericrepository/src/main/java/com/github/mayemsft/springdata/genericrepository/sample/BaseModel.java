package com.github.mayemsft.springdata.genericrepository.sample;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

/**
 * Project: demo
 * Package: com.github.mayemsft.springdata.genericrepository.sample
 * <p>
 * User: ashisas
 * Date: 26-02-2022
 * Time: 15:57
 * <p>
 * Created with IntelliJ IDEA
 * To change this template use File | Settings | File Templates.
 */
@MappedSuperclass
public class BaseModel implements Serializable {
        @Id
        @GeneratedValue(generator = "uuid")
        @GenericGenerator(name = "uuid", strategy = "uuid2")
        private String id;
    public BaseModel() {

        }
        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
}
