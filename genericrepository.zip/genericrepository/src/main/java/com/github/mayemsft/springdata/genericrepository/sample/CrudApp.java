package com.github.mayemsft.springdata.genericrepository.sample;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.CharStreams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.github.mayemsft.springdata.genericrepository.CrudRepositoryHelper;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Hello world!
 *
 */
@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.github.mayemsft.springdata.genericrepository.sample")
@ComponentScan(basePackages = "com.*")
public class CrudApp implements CommandLineRunner
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CrudApp.class);
	
	@Autowired
	private ApplicationContext context;

	public static void main(String[] args) {
		
		SpringApplication.run(CrudApp.class, args);

	}


	@Override
	public void run(String... args) throws Exception {
		
		CrudRepositoryHelper<Person, String> crudRepositoryHelper =null;

		List<CustomerEntity> customers = getObjectFromJson(readFile("customer.json"), new TypeReference<List<CustomerEntity>>() {
		});
		List<UserEntity> users = getObjectFromJson(readFile("user.json"), new TypeReference<List<UserEntity>>() {
		});
		List<Person> person = getObjectFromJson(readFile("person.json"), new TypeReference<List<Person>>() {
		});
		List<Object> obj = new ArrayList();
		obj.add(customers);
		obj.add(users);
		obj.add(person);
		List<Object> keys = new ArrayList<>();
	    obj.stream().forEach( objarr -> {
	    	List<Object> k = (List<Object>) objarr;
			keys.add(k.get(0).getClass());
		});
		CrudRepositoryHelper<List<Object>, String> listofEntity = new CrudRepositoryHelper<List<Object>, String>(keys, String.class, context);
		//save person1
		Map<Object,Object> bean = (Map<Object, Object>) context.getBean("JPAProperty");
		System.out.println("start time :" +new Date());

		long endTime = System.currentTimeMillis();
				obj.parallelStream().forEach(f -> {
					System.out.println( "Thread -> "+ Thread.currentThread().getName() +" " );
					JpaRepository rep = (JpaRepository) bean.get(((ArrayList) f).get(0).getClass());
					rep.saveAll((Iterable) f);
				});


		long startTime = System.currentTimeMillis();
		System.out.println("end time :" +new Date());
		long parallelStreamTimetaken = (endTime - startTime) / 1000;
		System.out.println("Time required with parallelStream() : " + parallelStreamTimetaken);
	}


	private void printPersons(Iterable<Person> personIIterable) {
		personIIterable.forEach(new Consumer<Person>() {

			@Override
			public void accept(Person t) {
				LOGGER.info(t.toString());
				
			}
		});
	}
	private static final ObjectMapper mapper;

	static {
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		//mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		// mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
	}
	public static String readFile(String filename) {
		InputStream is = null;
		try {
			ClassPathResource resource = new ClassPathResource("data/" + filename);
			is = resource.getInputStream();
			return CharStreams.toString(new InputStreamReader(is, "UTF-8"));
		} catch (Exception e) {
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
				}
			}
		}
		return null;
	}
	public static <T> T getObjectFromJson(String json, TypeReference<T> clazz) {
		if (json == null) {
			return null;
		}
		try {
			return (T) mapper.readValue(json, clazz);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
