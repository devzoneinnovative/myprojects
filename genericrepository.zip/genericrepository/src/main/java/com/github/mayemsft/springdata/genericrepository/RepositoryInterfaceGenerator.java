package com.github.mayemsft.springdata.genericrepository;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.core.support.RepositoryComposition.RepositoryFragments;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.web.context.support.GenericWebApplicationContext;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.tools.*;

class RepositoryInterfaceGenerator<Entity, ID> {

	
	private Class<? extends Repository<Entity, ID>> interfaceClass;
	private ApplicationContext context;
	private static ApplicationContext applicationContext;
	private Map<String, Repository<Entity, ID>> queryRepos = new HashMap<String, Repository<Entity, ID>>();
	private ConfigurableBeanFactory beanFactory;
	private JpaRepository<Entity, ID> crudRepo;
	private Map<Object,JpaRepository<Entity, ID>> ListcrudRepo;

	private GenericWebApplicationContext context1;

			RepositoryInterfaceGenerator(Class<? extends Repository<Entity, ID>> interfaceClass, ApplicationContext context) {
		this.interfaceClass = interfaceClass;
		this.context = context;

	}

	
	@SuppressWarnings({ "unchecked" })
	Repository<Entity, ID> genQueryRepository(Class<Entity> cls, Class<ID> id, String methodName, boolean multiple, Class<?>... paramTypes) throws Exception {
		if(!queryRepos.containsKey(methodName)) {
			Class<?> repoCls = this.genQueryCode(cls, id, methodName, multiple, paramTypes);
			makeRepositoryInstance(repoCls);
			Repository<Entity, ID> repo = (Repository<Entity, ID>) makeRepositoryInstance(repoCls);
			queryRepos.put(methodName, repo);
		} 
		return queryRepos.get(methodName);
		
	}
	
	@SuppressWarnings({  "unchecked" })
	Repository<Entity, ID> genCrudRepository(Class<Entity> cls, Class<ID> id) throws Exception {
		
		if(this.crudRepo == null) {
			Class<?> repoCls = this.genCrudCode(cls, id);
			//makeRepositoryInstance(repoCls);
			this.crudRepo = (JpaRepository<Entity, ID>) makeRepositoryInstance(repoCls);
		}
		return this.crudRepo;
	}
	Map<Object,JpaRepository<Entity, ID>> genCrudRepository(List<Object> cls, Class<ID> id) throws Exception {

		if(this.crudRepo == null) {
		/*	List<Class<?>> cl = new ArrayList<>();
			Set<Object> set = new HashSet<>(cls);
			for(Object cls1 : set) {
				Class<?> repoCls = this.genCrudCode((Class<Entity>) cls1.getClass(), id);
				cl.add(repoCls);
			}*/
			//makeRepositoryInstance(cls);
			this.ListcrudRepo = (Map<Object, JpaRepository<Entity, ID>>) makeRepositoryInstance(cls);
		}
		return this.ListcrudRepo;
	}


	private Class<?> genQueryCode(Class<Entity> cls, Class<ID> id, String methodName, boolean multiple, Class<?>... paramTypes) throws Exception {
		Package pkg = cls.getPackage();
		StringBuilder sourceCode = new StringBuilder();
		
		String className = cls.getSimpleName()+methodName+"generatedRepository";
		String pkgName = pkg.getName()+".repository";
		sourceCode.append("package "+pkgName+";\n");

		sourceCode.append("import org.springframework.data.jpa.repository.JpaRepository;\n");
		//sourceCode.append("import org.springframework.data.cassandra.repository.Query;\n");
		sourceCode.append("import org.springframework.stereotype.Repository;\n");
		sourceCode.append("import "+interfaceClass.getName()+";\n");
		sourceCode.append("import "+cls.getName()+";\n");
		
		sourceCode.append("\n");
		
		sourceCode.append("public interface " + className + " extends "+interfaceClass.getSimpleName()+"<"+ cls.getSimpleName()+", "+id.getSimpleName()+"> {\n");
		sourceCode.append("   @AllowFiltering\n");
		if(multiple) {
			sourceCode.append("   Iterable<"+cls.getSimpleName()+"> "+methodName+"(");
		} else {
			sourceCode.append("   "+cls.getSimpleName()+" "+methodName+"(");
		}
		for (int i=0;i<paramTypes.length;i++) {
			if(i>0) {
				sourceCode.append(", ");
			}
			sourceCode.append(paramTypes[i].getSimpleName()+" arg"+i);
		}
		sourceCode.append(");\n");
		sourceCode.append("}\n");
//		System.out.println(sourceCode.toString());
		return CompilerFactory.getInstance().complie(pkgName+"."+className, sourceCode.toString());
		
	}
	
	private Class<?> genCrudCode(Class<Entity> cls, Class<ID> id) throws Exception {
		Package pkg = cls.getPackage();
		StringBuilder sourceCode = new StringBuilder();
		String className = cls.getSimpleName()+"generatedRepository";
		String pkgName = pkg.getName()+".repository";
		sourceCode.append("package "+pkgName+";\n");
		sourceCode.append("import "+interfaceClass.getName()+";\n");
		sourceCode.append("import "+cls.getName()+";\n");
		sourceCode.append("import org.springframework.stereotype.Repository;\n");
		sourceCode.append("\n");
		sourceCode.append("@Repository"+"\n");
		sourceCode.append("public interface "+className+" extends "+interfaceClass.getSimpleName()+"<"+ cls.getSimpleName()+", "+id.getSimpleName()+"> {\n");
		sourceCode.append("}\n");
		System.out.println(sourceCode.toString());
		try {
		//	Map<String,Class<?>> map  = createTempalte(cls, id);
			//makeRepositoryInstance(cls);
		}
		catch (Exception e) {

		}
		return CompilerFactory.getInstance().complie(pkgName+"."+className, sourceCode.toString());
	}


	private Object makeRepositoryInstance(Class<?> repositoryClass,String s) {

		LocalContainerEntityManagerFactoryBean bean = context.getBean(LocalContainerEntityManagerFactoryBean.class);
		EntityManagerFactory emf = (EntityManagerFactory)
				context.getBean("entityManagerFactory", javax.persistence.EntityManagerFactory.class);
		RepositoryFragments repositoryFragmentsToUse = (RepositoryFragments) Optional.empty() //
				.orElseGet(RepositoryFragments::empty);
		EntityManager em = emf.createEntityManager();
		JpaRepositoryFactory factory = new JpaRepositoryFactory(em);
		RepositoryFactorySupport factory1 = new JpaRepositoryFactory(em);
		// factory.getRepository(UserRepository.class);
		factory.setBeanClassLoader(CompilerFactory.getInstance().getClassLoader());
		String[] beanNames = context.getBeanDefinitionNames();
		SimpleJpaRepository<Class, Serializable> jpaRepository = new SimpleJpaRepository<Class, Serializable>
				((Class<Class>) repositoryClass, em);
		return jpaRepository;

	}
	private Object makeRepositoryInstance(Class<?> repositoryClass) {

		JpaRepository bean = context.getBean(JpaRepository.class);

		return bean;

	}


	private Map<Object,JpaRepository<Entity, ID>> makeRepositoryInstance(List<Object> repositoryClass) {
		List<Object> obj = new ArrayList<>();
		Map<Object,JpaRepository<Entity, ID>>  map = new HashMap<>();
		ConfigurableListableBeanFactory beanFactory = ((ConfigurableApplicationContext) context).getBeanFactory();


		for (Object repo : repositoryClass) {
			JpaRepository bean = context.getBean(JpaRepository.class);
			obj.add(bean);
			map.put(repo,bean);
		}
		beanFactory.registerSingleton("JPAProperty", map);
		return map;

	}




	public Map<String,Class<?>> createTempalte(Class<Entity> cls, Class<ID> id) throws IOException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
		Package pkg = cls.getPackage();
		StringBuilder sourceCode = new StringBuilder();
		String className = cls.getSimpleName()+"generatedRepository";
		String pkgName = pkg.getName()+".repository";
		sourceCode.append("package "+pkgName+";\n");
		sourceCode.append("import "+interfaceClass.getName()+";\n");
		sourceCode.append("import "+cls.getName()+";\n");
		sourceCode.append("import org.springframework.stereotype.Repository;\n");
		sourceCode.append("import org.springframework.data.repository.NoRepositoryBean;\n");
		sourceCode.append("\n");
		sourceCode.append("@NoRepositoryBean"+"\n");

		System.out.println(sourceCode.toString());
		File sourceFile = File.createTempFile(className, ".java");
		sourceFile.deleteOnExit();
		// generate the source code, using the source filename as the class name

		String classname = sourceFile.getName().split("\\.")[0];
		String clName = className;
		sourceCode.append("public interface "+sourceFile.getName().split("\\.")[0]+" extends "+interfaceClass.getSimpleName()+"<"+ cls.getSimpleName()+", "+id.getSimpleName()+"> {\n");
		sourceCode.append("}\n");
		// write the source code into the source file
		FileWriter writer = new FileWriter(sourceFile);
		writer.write(String.valueOf(sourceCode));
		writer.close();

		// compile the source file
		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, null, null);
		File parentDirectory = sourceFile.getParentFile();
		fileManager.setLocation(StandardLocation.CLASS_OUTPUT, Arrays.asList(parentDirectory));
		Iterable<? extends JavaFileObject> compilationUnits = fileManager.getJavaFileObjectsFromFiles(Arrays.asList(sourceFile));
		compiler.getTask(null, fileManager, null, null, null, compilationUnits).call();
		fileManager.close();

		// load the compiled class
		URLClassLoader classLoader = URLClassLoader.newInstance(new URL[] { parentDirectory.toURI().toURL() });
		Map<String,Class<?>> map = new HashMap<>();
		 map.put(sourceFile.getName().split("\\.")[0],classLoader.loadClass(sourceFile.getName().split("\\.")[0]));
		 return map;

		// call a method on the loaded class
		//  Method helloMethod = helloClass.getDeclaredMethod("hello");
		//helloMethod.invoke(helloClass.newInstance());
	}
}
